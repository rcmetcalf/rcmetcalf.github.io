
$.fullCalendar.lang("id", {
	buttonText: {
		month: "Bulan",
		week: "Minggu",
		day: "Hari",
		list: "Agenda"
	},
	allDayHtml: "Sehari<br/>penuh",
	eventLimitText: "lebih"
});
