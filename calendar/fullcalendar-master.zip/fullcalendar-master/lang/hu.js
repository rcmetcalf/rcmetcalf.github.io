
$.fullCalendar.lang("hu", {
	buttonText: {
		month: "Hónap",
		week: "Hét",
		day: "Nap",
		list: "Napló"
	},
	allDayText: "Egész nap",
	eventLimitText: "további"
});
