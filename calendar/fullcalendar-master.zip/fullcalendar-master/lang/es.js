
$.fullCalendar.lang("es", {
	buttonText: {
		month: "Mes",
		week: "Semana",
		day: "Día",
		list: "Agenda"
	},
	allDayHtml: "Todo<br/>el día",
	eventLimitText: "más"
});
