
$.fullCalendar.lang("el", {
	buttonText: {
		month: "Μήνας",
		week: "Εβδομάδα",
		day: "Ημέρα",
		list: "Ατζέντα"
	},
	allDayText: "Ολοήμερο",
	eventLimitText: "περισσότερα"
});
