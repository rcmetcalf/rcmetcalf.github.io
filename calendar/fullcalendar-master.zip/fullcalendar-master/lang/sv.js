
$.fullCalendar.lang("sv", {
	buttonText: {
		month: "Månad",
		week: "Vecka",
		day: "Dag",
		list: "Program"
	},
	allDayText: "Heldag",
	eventLimitText: "till"
});
