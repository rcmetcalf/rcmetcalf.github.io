
$.fullCalendar.lang("nb", {
	buttonText: {
		month: "Måned",
		week: "Uke",
		day: "Dag",
		list: "Agenda"
	},
	allDayText: "Hele dagen",
	eventLimitText: "til"
});
