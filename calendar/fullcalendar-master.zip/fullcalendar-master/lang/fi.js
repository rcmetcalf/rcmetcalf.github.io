
$.fullCalendar.lang("fi", {
	buttonText: {
		month: "Kuukausi",
		week: "Viikko",
		day: "Päivä",
		list: "Tapahtumat"
	},
	allDayText: "Koko päivä",
	eventLimitText: "lisää"
});
